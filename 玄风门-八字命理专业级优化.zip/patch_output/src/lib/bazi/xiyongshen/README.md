# ⚠️ 本目录状态说明（V2.0 架构审计，2026）

**本目录（105 个文件的多引擎喜用神系统：StrengthEngine / PatternEngine /
ClimateEngine / BalanceEngine / MedicineEngine / BridgeEngine / SeasonEngine
+ fusion 决策融合 + AccuracyCenter）目前【未接入任何生产代码路径】。**

## 实际生产中喜用神计算使用的是哪个模块？

- 免费版排盘（`calculator.ts` → `useBazi.ts` 钩子）使用同目录上一级的
  `../xiyongshen.ts`（单文件简化版）。
- 付费专业报告（`/api/pro/master-report`）使用 `../pro/xiyongEngine.ts` +
  `../pro/xiyongDatabase.ts`（配置驱动、知识库支撑的独立实现）。

本目录（`xiyongshen/`）只被以下位置引用：
- `tests/bazi/ruleRegression/*.test.ts`（回归测试，验证本引擎自身逻辑）
- `foundation/`（清单已标注为实验性、未完全集成的架构探索目录）

## 为什么不直接删除？

本目录的实现质量本身并不差，甚至在"多引擎融合决策"这个设计思路上比另外两套实现更完整，
且有独立的测试覆盖。按照项目"不因为代码看起来更漂亮就删除已实现功能"的原则，
在没有明确产品决策之前不应该删除。

## 需要产品侧决策的问题

1. 是否要激活本引擎替换现有两套实现之一（免费版简化版 / 付费版 xiyongEngine）？
2. 如果激活，替换免费版还是付费版，还是作为"大师版"新增第三档？
3. 如果确认不再需要，应如何归档（移出 src/ 主目录 / 单独打 tag 保留 git 历史）？

在明确决策之前，本目录代码原样保留，不建议任何人在不知情的情况下修改或依赖它。
